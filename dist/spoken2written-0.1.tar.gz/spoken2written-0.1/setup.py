from distutils.core import setup

setup(
    name='spoken2written',
    version='0.1',
    packages=['spoken2written',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.md').read(),
)